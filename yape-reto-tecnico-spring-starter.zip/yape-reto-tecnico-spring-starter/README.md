# Reto técnico (starter) - Yape (Spring Boot + Docker)

Starter listo para levantar un flujo típico del reto con **2 microservicios** y **MySQL**:

- **transaction-service** (Spring Boot Web + JPA): expone API REST para crear/listar transacciones y llama a antifraud-service
- **antifraud-service** (Spring Boot Web): endpoint para validar una transacción (regla simple por monto)
- **mysql** (MySQL 8)

> Ajusta endpoints/reglas/modelo según el enunciado exacto.

---

## Requisitos
- Docker Desktop (o Docker Engine) + Docker Compose

---

## Levantar todo con Docker

```bash
docker compose up --build
```

Servicios:
- transaction-service: http://localhost:8080
- antifraud-service: http://localhost:8081

Health:
- http://localhost:8080/actuator/health
- http://localhost:8081/actuator/health

---

## Probar rápido con cURL

### Crear transacción
```bash
curl -X POST http://localhost:8080/transactions \
  -H "Content-Type: application/json" \
  -d '{
    "externalId":"ext-001",
    "amount": 25.50,
    "currency":"PEN",
    "payerDocument":"12345678",
    "payeeDocument":"87654321",
    "description":"Pago de prueba"
  }'
```

### Listar transacciones
```bash
curl http://localhost:8080/transactions
```

### Antifraude directo
```bash
curl -X POST http://localhost:8081/validate \
  -H "Content-Type: application/json" \
  -d '{ "amount": 5000, "currency":"PEN" }'
```

---

## Estructura
```
.
├─ docker-compose.yml
├─ transaction-service
│  ├─ Dockerfile
│  ├─ pom.xml
│  └─ src/main/java/...
└─ antifraud-service
   ├─ Dockerfile
   ├─ pom.xml
   └─ src/main/java/...
```

---

## Notas para adaptar al enunciado
- Si el reto pide **idempotencia**, usa `externalId` como llave única (ya está unique en BD).
- Si pide **mensajería** (Kafka/Rabbit/Azure Service Bus), aquí puedes enchufar publisher/consumer.
- Si pide **tests**, agrega Spring Boot Test + MockMvc.
