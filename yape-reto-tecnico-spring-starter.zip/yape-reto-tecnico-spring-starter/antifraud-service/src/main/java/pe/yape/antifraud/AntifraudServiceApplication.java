package pe.yape.antifraud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AntifraudServiceApplication {
  public static void main(String[] args) {
    SpringApplication.run(AntifraudServiceApplication.class, args);
  }
}
