package pe.yape.antifraud.api;

import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pe.yape.antifraud.api.dto.AntifraudRequest;
import pe.yape.antifraud.api.dto.AntifraudResponse;

@RestController
public class AntifraudController {

  @Value("${rules.max-approve-amount:1000}")
  private double maxApproveAmount;

  @PostMapping("/validate")
  public ResponseEntity<AntifraudResponse> validate(@Valid @RequestBody AntifraudRequest req) {
    boolean approved = req.amount() <= maxApproveAmount;
    String status = approved ? "APPROVED" : "REJECTED";
    int score = approved ? 10 : 90;

    return ResponseEntity.ok(new AntifraudResponse(status, score, maxApproveAmount));
  }
}
