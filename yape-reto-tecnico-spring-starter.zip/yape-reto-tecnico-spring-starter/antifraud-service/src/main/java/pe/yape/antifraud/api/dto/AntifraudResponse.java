package pe.yape.antifraud.api.dto;

public record AntifraudResponse(
    String status,
    int score,
    double maxApproveAmount
) {}
