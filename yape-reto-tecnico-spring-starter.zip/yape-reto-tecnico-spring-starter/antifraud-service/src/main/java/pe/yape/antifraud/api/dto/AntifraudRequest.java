package pe.yape.antifraud.api.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

public record AntifraudRequest(
    @NotNull @Positive Double amount,
    String currency,
    String externalId,
    String payerDocument,
    String payeeDocument
) {}
