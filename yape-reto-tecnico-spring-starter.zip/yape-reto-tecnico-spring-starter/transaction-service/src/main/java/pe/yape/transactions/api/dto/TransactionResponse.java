package pe.yape.transactions.api.dto;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

public record TransactionResponse(
    Long id,
    String externalId,
    BigDecimal amount,
    String currency,
    String payerDocument,
    String payeeDocument,
    String description,
    AntifraudResult antifraud,
    OffsetDateTime createdAt
) {
  public record AntifraudResult(String status, Integer score) {}
}
