package pe.yape.transactions.domain;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.OffsetDateTime;

@Entity
@Table(name = "transactions", uniqueConstraints = {
    @UniqueConstraint(name = "uk_transactions_external_id", columnNames = "external_id")
})
public class Transaction {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(name = "external_id", nullable = false, length = 64)
  private String externalId;

  @Column(nullable = false, precision = 12, scale = 2)
  private BigDecimal amount;

  @Column(nullable = false, length = 3)
  private String currency = "PEN";

  @Column(name = "payer_document", nullable = false, length = 32)
  private String payerDocument;

  @Column(name = "payee_document", nullable = false, length = 32)
  private String payeeDocument;

  @Column(length = 255)
  private String description;

  @Column(name = "antifraud_status", length = 16)
  private String antifraudStatus;

  @Column(name = "antifraud_score")
  private Integer antifraudScore;

  @Column(name = "created_at", nullable = false, updatable = false)
  private OffsetDateTime createdAt;

  @PrePersist
  void prePersist() {
    this.createdAt = OffsetDateTime.now();
  }

  // getters/setters
  public Long getId() { return id; }

  public String getExternalId() { return externalId; }
  public void setExternalId(String externalId) { this.externalId = externalId; }

  public BigDecimal getAmount() { return amount; }
  public void setAmount(BigDecimal amount) { this.amount = amount; }

  public String getCurrency() { return currency; }
  public void setCurrency(String currency) { this.currency = currency; }

  public String getPayerDocument() { return payerDocument; }
  public void setPayerDocument(String payerDocument) { this.payerDocument = payerDocument; }

  public String getPayeeDocument() { return payeeDocument; }
  public void setPayeeDocument(String payeeDocument) { this.payeeDocument = payeeDocument; }

  public String getDescription() { return description; }
  public void setDescription(String description) { this.description = description; }

  public String getAntifraudStatus() { return antifraudStatus; }
  public void setAntifraudStatus(String antifraudStatus) { this.antifraudStatus = antifraudStatus; }

  public Integer getAntifraudScore() { return antifraudScore; }
  public void setAntifraudScore(Integer antifraudScore) { this.antifraudScore = antifraudScore; }

  public OffsetDateTime getCreatedAt() { return createdAt; }
}
