package pe.yape.transactions.api;

import jakarta.validation.Valid;
import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pe.yape.transactions.api.dto.CreateTransactionRequest;
import pe.yape.transactions.api.dto.TransactionResponse;
import pe.yape.transactions.service.TransactionAppService;

@RestController
@RequestMapping
public class TransactionController {

  private final TransactionAppService service;

  public TransactionController(TransactionAppService service) {
    this.service = service;
  }

  @GetMapping("/transactions")
  public ResponseEntity<List<TransactionResponse>> list() {
    return ResponseEntity.ok(service.list());
  }

  @PostMapping("/transactions")
  public ResponseEntity<TransactionResponse> create(@Valid @RequestBody CreateTransactionRequest req) {
    return ResponseEntity.status(201).body(service.create(req));
  }
}
