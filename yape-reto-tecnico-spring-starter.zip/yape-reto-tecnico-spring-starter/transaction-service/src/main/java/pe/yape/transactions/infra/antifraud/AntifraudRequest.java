package pe.yape.transactions.infra.antifraud;

import java.math.BigDecimal;

public record AntifraudRequest(
    BigDecimal amount,
    String currency,
    String externalId,
    String payerDocument,
    String payeeDocument
) {}
