package pe.yape.transactions.infra.antifraud;

public record AntifraudResponse(
    String status,
    Integer score,
    Double maxApproveAmount
) {}
