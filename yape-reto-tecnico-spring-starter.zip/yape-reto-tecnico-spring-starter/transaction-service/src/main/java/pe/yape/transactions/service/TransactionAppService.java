package pe.yape.transactions.service;

import java.util.List;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import pe.yape.transactions.api.dto.CreateTransactionRequest;
import pe.yape.transactions.api.dto.TransactionResponse;
import pe.yape.transactions.domain.Transaction;
import pe.yape.transactions.domain.TransactionRepository;
import pe.yape.transactions.infra.antifraud.AntifraudClient;
import pe.yape.transactions.infra.antifraud.AntifraudRequest;
import pe.yape.transactions.infra.antifraud.AntifraudResponse;

@Service
public class TransactionAppService {

  private final TransactionRepository repository;
  private final AntifraudClient antifraudClient;

  public TransactionAppService(TransactionRepository repository, AntifraudClient antifraudClient) {
    this.repository = repository;
    this.antifraudClient = antifraudClient;
  }

  @Transactional(readOnly = true)
  public List<TransactionResponse> list() {
    return repository.findAll().stream()
        .sorted((a,b) -> Long.compare(b.getId(), a.getId()))
        .map(this::toResponse)
        .toList();
  }

  @Transactional
  public TransactionResponse create(CreateTransactionRequest req) {
    // Idempotencia simple: si ya existe, devolverlo
    var existing = repository.findByExternalId(req.externalId());
    if (existing.isPresent()) return toResponse(existing.get());

    AntifraudResponse antifraud;
    try {
      antifraud = antifraudClient.validate(new AntifraudRequest(
          req.amount(),
          req.currency() == null || req.currency().isBlank() ? "PEN" : req.currency(),
          req.externalId(),
          req.payerDocument(),
          req.payeeDocument()
      ));
    } catch (Exception e) {
      // En un reto puedes decidir fail-open vs fail-closed.
      // Aquí: fail-closed (REJECTED) pero persistimos.
      antifraud = new AntifraudResponse("REJECTED", 999, null);
    }

    Transaction t = new Transaction();
    t.setExternalId(req.externalId());
    t.setAmount(req.amount());
    t.setCurrency(req.currency() == null || req.currency().isBlank() ? "PEN" : req.currency());
    t.setPayerDocument(req.payerDocument());
    t.setPayeeDocument(req.payeeDocument());
    t.setDescription(req.description());
    t.setAntifraudStatus(antifraud.status());
    t.setAntifraudScore(antifraud.score());

    try {
      t = repository.save(t);
    } catch (DataIntegrityViolationException ex) {
      // Si hubo carrera (dos requests con mismo externalId), devolvemos el existente
      var found = repository.findByExternalId(req.externalId());
      if (found.isPresent()) return toResponse(found.get());
      throw ex;
    }

    return toResponse(t);
  }

  private TransactionResponse toResponse(Transaction t) {
    return new TransactionResponse(
        t.getId(),
        t.getExternalId(),
        t.getAmount(),
        t.getCurrency(),
        t.getPayerDocument(),
        t.getPayeeDocument(),
        t.getDescription(),
        new TransactionResponse.AntifraudResult(t.getAntifraudStatus(), t.getAntifraudScore()),
        t.getCreatedAt()
    );
  }
}
